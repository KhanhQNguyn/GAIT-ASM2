from __future__ import annotations

import random

import pygame

from frog import Frog
from grid import TerrainGrid
from pathfinding import AStarResult, find_path, path_cost_breakdown
from effects import Particle, ParticleSystem
from audio_fx import load_or_synth, SFX_SPEC, synth_tone

from settings import (
    COLOR_BG,
    COLOR_PANEL_BG,
    COLOR_PANEL_BORDER,
    COLOR_PATH,
    COLOR_TEXT,
    FONT_SIZE,
    FPS,
    FROG_SPRITE,
    GRASS_TEXTURE,
    GRID_COLS,
    GRID_ROWS,
    GRID_PIXEL_WIDTH,
    KEYBINDS,
    MUD_TEXTURE,
    REVEAL_CELLS_PER_FRAME,
    SCREEN_HEIGHT,
    SCREEN_WIDTH,
    SFX_PATHS,
    TERRAIN_COLOR,
    TERRAIN_COST,
    TILE_SIZE,
    WALL_TEXTURE,
    WATER_TEXTURE,
    Terrain,
)

import io
import struct
import math

def IDLE(): pass # placeholder for deleted lines so line numbers don't shift too much (we can just replace with empty string)


IDLE = "idle"
REVEALING = "revealing"
FOLLOWING = "following"


def build_grid() -> TerrainGrid:
    grid = TerrainGrid(GRID_COLS, GRID_ROWS)
    return grid


def load_surface(path):
    try:
        if path.exists():
            return pygame.image.load(str(path)).convert_alpha()
    except Exception as exc:
        print(f"Failed to load {path.name}: {exc}")
    return None


def choose_random_grass_start(grid: TerrainGrid) -> tuple[int, int]:
    grass_cells = grid.grass_cells()
    if not grass_cells:
        raise RuntimeError("No grass cells available for frog spawn")
    return random.choice(grass_cells)


def invalidate_current_path(grid: TerrainGrid, frog: Frog):
    grid.reset_search_state()
    grid.goal_cell = None
    frog.velocity.update(0, 0)
    frog.set_path([])


def summarize_path_terrain(grid: TerrainGrid, path: list[tuple[int, int]]) -> dict[str, int]:
    counts = {Terrain.GRASS: 0, Terrain.MUD: 0, Terrain.WATER: 0}
    for col, row in path:
        cell = grid.get_cell(col, row)
        if cell is None:
            continue
        if cell.terrain in counts:
            counts[cell.terrain] += 1
    return counts


def draw_panel_frame(screen: pygame.Surface, rect: pygame.Rect, bg_color: tuple, border_color: tuple, radius: int = 10):
    shadow_rect = rect.copy()
    shadow_rect.x += 3
    shadow_rect.y += 4
    shadow_surf = pygame.Surface(shadow_rect.size, pygame.SRCALPHA)
    pygame.draw.rect(shadow_surf, (0, 0, 0, 80), shadow_surf.get_rect(), border_radius=radius)
    screen.blit(shadow_surf, shadow_rect.topleft)
    
    pygame.draw.rect(screen, bg_color, rect, border_radius=radius)
    pygame.draw.rect(screen, border_color, rect, 2, border_radius=radius)


def draw_terrain_swatch(screen: pygame.Surface, x: int, y: int, terrain: str):
    swatch_rect = pygame.Rect(x, y + 6, 10, 10)
    pygame.draw.rect(screen, TERRAIN_COLOR[terrain], swatch_rect)


def main() -> int:
    pygame.mixer.pre_init(44100, -16, 2, 512)
    pygame.init()
    try:
        pygame.mixer.init()
        sounds = {
            key: load_or_synth(SFX_PATHS[key], **spec)
            for key, spec in SFX_SPEC.items()
        }
    except Exception:
        class DummySound:
            def play(self): pass
        dummy = DummySound()
        sounds = {key: dummy for key in SFX_SPEC}

    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("A* over a weighted-cost grid")
    clock = pygame.time.Clock()
    font = pygame.font.Font(None, FONT_SIZE)

    frog_sprite = load_surface(FROG_SPRITE)
    terrain_textures = {
        Terrain.GRASS: load_surface(GRASS_TEXTURE),
        Terrain.MUD: load_surface(MUD_TEXTURE),
        Terrain.WATER: load_surface(WATER_TEXTURE),
        Terrain.WALL: load_surface(WALL_TEXTURE),
    }
    if frog_sprite is None:
        print("Running with frog fallback drawing because frog sprite could not be loaded.")
        frog_sprite = None
    if any(texture is None for texture in terrain_textures.values()):
        missing = [terrain for terrain, texture in terrain_textures.items() if texture is None]
        print(f"Using per-terrain fallback colors for missing textures: {', '.join(missing)}")

    grid = build_grid()
    start_cell = choose_random_grass_start(grid)
    grid.set_start_cell(*start_cell)
    start_center = grid.cell_to_world_center(*start_cell)
    frog = Frog(*start_center, sprite_path=FROG_SPRITE if frog_sprite is not None else None)

    state = IDLE
    result: AStarResult | None = None
    reveal_cursor = 0
    show_final_path = False
    allow_diagonal = True
    show_heatmap = False
    show_cost_labels = True
    hud_message = ""
    hud_message_time = 0.0
    goal_cell: tuple[int, int] | None = None
    last_path_breakdown: list[tuple[tuple[int, int], float, float]] = []

    particles = ParticleSystem()
    frog_step_dist = 0.0
    think_timer = 0.0
    search_time = 0.0
    footstep_timer = 0.0
    shake_timer = 0.0
    ambient_timer = 0.0

    grid.goal_cell = None

    def reset_world() -> None:
        nonlocal grid, frog, state, result, reveal_cursor, show_final_path, goal_cell, hud_message, hud_message_time
        nonlocal start_cell
        nonlocal last_path_breakdown
        grid = build_grid()
        start_cell = choose_random_grass_start(grid)
        grid.set_start_cell(*start_cell)
        invalidate_current_path(grid, frog)
        frog.pos = pygame.Vector2(*grid.cell_to_world_center(*start_cell))
        frog.velocity.update(0, 0)
        frog.set_path([])
        state = IDLE
        result = None
        reveal_cursor = 0
        show_final_path = False
        goal_cell = None
        last_path_breakdown = []
        hud_message = ""
        hud_message_time = 0.0
        search_time = 0.0

    def set_message(text: str, duration: float = 1.5) -> None:
        nonlocal hud_message, hud_message_time
        hud_message = text
        hud_message_time = duration

    def handle_right_click(mouse_pos: tuple[int, int]) -> None:
        nonlocal state, result, reveal_cursor, show_final_path, goal_cell, start_cell
        nonlocal last_path_breakdown, search_time
        if state != IDLE:
            return

        start_cell = grid.world_to_cell(frog.pos.x, frog.pos.y)
        grid.set_start_cell(*start_cell)

        col, row = grid.world_to_cell(*mouse_pos)
        if not grid.in_bounds(col, row):
            set_message("Target outside the grid")
            sounds["invalid"].play()
            return
        if grid.cost(col, row) == float("inf"):
            set_message("Target is a wall")
            sounds["invalid"].play()
            return
        if not grid.is_reachable(col, row):
            set_message("Target unreachable from the frog", duration=2.5)
            sounds["invalid"].play()
            return

        goal_cell = (col, row)
        grid.goal_cell = goal_cell
        grid.reset_search_state()
        result = find_path(grid, start_cell, goal_cell, allow_diagonal)
        last_path_breakdown = path_cost_breakdown(grid, result.path)
        reveal_cursor = 0
        show_final_path = False
        search_time = 0.0
        state = REVEALING
        if not result.reachable:
            set_message("Target unreachable", duration=2.5)
            sounds["invalid"].play()
        else:
            sounds["path_found"].play()

    def handle_left_click(mouse_pos: tuple[int, int]) -> None:
        nonlocal state, result, reveal_cursor, show_final_path, goal_cell, start_cell, last_path_breakdown, search_time
        col, row = grid.world_to_cell(*mouse_pos)
        if not grid.in_bounds(col, row):
            return

        frog_cell = grid.world_to_cell(frog.pos.x, frog.pos.y)
        if (col, row) == frog_cell:
            grid.set_terrain(col, row, Terrain.GRASS)
            grid.set_start_cell(*frog_cell)
            set_message("Cannot place wall on frog", duration=1.8)
            sounds["invalid"].play()
            return

        cell = grid.get_cell(col, row)
        if cell is None:
            return

        new_terrain = Terrain.GRASS if cell.terrain == Terrain.WALL else Terrain.WALL
        if not grid.set_terrain(col, row, new_terrain):
            return

        cell_center = grid.cell_to_world_center(col, row)
        particles.emit_burst(cell_center, color=TERRAIN_COLOR[new_terrain], count=12, speed=110)
        sounds["wall_pop"].play()

        state = IDLE
        result = None
        reveal_cursor = 0
        show_final_path = False
        goal_cell = None
        last_path_breakdown = []
        search_time = 0.0
        start_cell = frog_cell
        grid.set_start_cell(*start_cell)
        invalidate_current_path(grid, frog)

    def update(dt: float) -> None:
        nonlocal state, reveal_cursor, show_final_path, result, hud_message_time, hud_message, start_cell
        nonlocal frog_step_dist, think_timer, search_time, footstep_timer, shake_timer, ambient_timer

        if hud_message_time > 0.0:
            hud_message_time = max(0.0, hud_message_time - dt)
            if hud_message_time == 0.0:
                hud_message = ""

        # Update particles
        particles.update(dt)
        shake_timer = max(0.0, shake_timer - dt)

        if state == IDLE:
            ambient_timer -= dt
            if ambient_timer <= 0:
                ambient_timer = random.uniform(0.3, 0.8)
                col = random.randint(0, GRID_COLS - 1)
                row = random.randint(0, GRID_ROWS - 1)
                cell = grid.get_cell(col, row)
                if cell:
                    center = grid.cell_to_world_center(col, row)
                    offset = (random.uniform(-16, 16), random.uniform(-16, 16))
                    pos = (center[0] + offset[0], center[1] + offset[1])
                    if cell.terrain == Terrain.WATER:
                        particles.particles.append(
                            Particle(pos, (0, -4), life=random.uniform(0.5, 1.2), color=(140, 200, 255), size=random.uniform(1, 2), gravity=-1, fade=True)
                        )
                    elif cell.terrain == Terrain.GRASS and random.random() < 0.2:
                        particles.particles.append(
                            Particle(pos, (random.uniform(-2, 2), random.uniform(-2, 2)), life=random.uniform(0.5, 1.5), color=(180, 230, 180), size=random.uniform(1, 2), gravity=0, fade=True)
                        )

        if state == REVEALING and result is not None:
            think_timer += dt
            search_time += dt
            if think_timer > 0.1:
                think_timer = 0
            
            reveal_cursor = min(reveal_cursor + REVEAL_CELLS_PER_FRAME, len(result.explored_order))
            if reveal_cursor >= len(result.explored_order):
                if result.reachable:
                    show_final_path = True
                    world_path = [grid.cell_to_world_center(*cell) for cell in result.path]
                    frog.set_path(world_path)
                    state = FOLLOWING
                else:
                    state = IDLE
            return

        if state == FOLLOWING:
            speed = frog.velocity.length()
            if speed > 10:
                frog_step_dist += speed * dt
                
                footstep_timer -= dt
                if footstep_timer <= 0:
                    footstep_timer = 0.18
                    frog_col, frog_row = grid.world_to_cell(frog.pos.x, frog.pos.y)
                    frog_cell = grid.get_cell(frog_col, frog_row)
                    t = frog_cell.terrain if frog_cell else Terrain.GRASS
                    freq = 220.0 if t == Terrain.GRASS else (120.0 if t == Terrain.MUD else 180.0)
                    try:
                        step_snd = synth_tone(frequency=freq, duration=0.04, volume=0.15, wave="sine")
                        step_snd.play()
                    except Exception:
                        pass
                
                frog_col, frog_row = grid.world_to_cell(frog.pos.x, frog.pos.y)
                frog_cell = grid.get_cell(frog_col, frog_row)
                if frog_cell:
                    t = frog_cell.terrain
                    if t == Terrain.GRASS:
                        particles.emit_trail(frog.pos, color=(180, 230, 180))
                    elif t == Terrain.MUD:
                        for _ in range(1):
                            vel = (random.uniform(-8, 8), random.uniform(-8, 8))
                            particles.particles.append(
                                Particle(frog.pos, vel, life=random.uniform(0.3, 0.5), color=TERRAIN_COLOR[t], size=random.uniform(3, 6), gravity=3)
                            )
                    elif t == Terrain.WATER:
                        particles.emit_terrain_splash(frog.pos, terrain_color=TERRAIN_COLOR[t], count=1)

            was_complete = frog.is_path_complete()
            advanced_waypoint = frog.follow_path(dt)
            if advanced_waypoint:
                particles.emit_burst(frog.pos, color=COLOR_PATH, count=10, speed=90)
                sounds["waypoint_pop"].play()

            if frog.is_path_complete():
                start_cell = grid.world_to_cell(frog.pos.x, frog.pos.y)
                grid.set_start_cell(*start_cell)
                state = IDLE
                frog_step_dist = 0
                if not was_complete:
                    shake_timer = 0.15
                    sounds["goal_fanfare"].play()
                    particles.emit_burst(frog.pos, color=(255, 255, 255), count=26, speed=180)
                    frog_col, frog_row = grid.world_to_cell(frog.pos.x, frog.pos.y)
                    frog_cell = grid.get_cell(frog_col, frog_row)
                    if frog_cell:
                        particles.emit_terrain_splash(frog.pos, terrain_color=TERRAIN_COLOR[frog_cell.terrain], count=8)

    def draw() -> None:
        screen.fill(COLOR_BG)
        revealed_cells = set(result.explored_order[:reveal_cursor]) if result is not None else set()
        
        is_revealing = (state == REVEALING)
        grid.draw(screen, terrain_textures, revealed_cells, show_final_path, show_heatmap, show_cost_labels, font, is_revealing, search_time)
        
        particles.draw(screen)

        offset_y = 0.0
        if state == REVEALING:
            offset_y = math.sin(search_time * 6) * 2
        frog.draw(screen, offset_y)

        if state == REVEALING:
            blink = int((pygame.time.get_ticks() / 150) % 2)
            if blink:
                think_surf = font.render("THINKING...", True, (255, 255, 0))
                screen.blit(think_surf, (frog.pos.x - 40, frog.pos.y - 40))

        y = GRID_ROWS * TILE_SIZE + 10
        lines = [
            f"Diagonal: {'ON' if allow_diagonal else 'OFF'}   Heatmap: {'ON' if show_heatmap else 'OFF'}   Cost Labels: {'ON' if show_cost_labels else 'OFF'}",
            "Right-click a reachable non-wall cell to run cost-weighted A*.",
            "Left-click toggles Wall/Grass (cannot edit frog cell).",
            "Legend: Grass=1  Mud=3  Water=5  Wall=impassable",
        ]
        if result is not None and result.reachable:
            lines.insert(1, f"Total Cost: {result.total_cost:.1f}")
        elif result is not None and not result.reachable:
            lines.insert(1, "Target unreachable")
        if hud_message:
            lines.insert(0, hud_message)

        # Translucent legend background
        legend_rect = pygame.Rect(8, y - 4, SCREEN_WIDTH - 16, len(lines) * 22 + 8)
        legend_bg = pygame.Surface(legend_rect.size, pygame.SRCALPHA)
        border_color = COLOR_PANEL_BORDER
        if hud_message and any(w in hud_message.lower() for w in ["unreachable", "wall", "outside"]):
            t = pygame.time.get_ticks() / 200.0
            interp = (math.sin(t) + 1.0) / 2.0
            border_color = (
                int(COLOR_TEXT[0] * interp + 255 * (1 - interp)),
                int(COLOR_TEXT[1] * interp + 191 * (1 - interp)),
                int(COLOR_TEXT[2] * interp + 0 * (1 - interp))
            )
        pygame.draw.rect(legend_bg, (*COLOR_PANEL_BG, 170), legend_bg.get_rect(), border_radius=8)
        pygame.draw.rect(legend_bg, (*border_color, 255), legend_bg.get_rect(), width=2, border_radius=8)
        screen.blit(legend_bg, legend_rect.topleft)

        for line in lines:
            label = font.render(line, True, COLOR_TEXT)
            screen.blit(label, (12, y))
            y += 22

        # This panel must never share pixel space with the grid canvas — it lives in the sidebar only.
        panel_width = SCREEN_WIDTH - GRID_PIXEL_WIDTH - 32
        panel_x = GRID_PIXEL_WIDTH + 16
        panel_y = 12
        panel_height = SCREEN_HEIGHT - 24
        panel_rect = pygame.Rect(panel_x, panel_y, panel_width, panel_height)
        
        draw_panel_frame(screen, panel_rect, COLOR_PANEL_BG, COLOR_PANEL_BORDER, 10)

        # Header strip
        header_rect = pygame.Rect(panel_x, panel_y, panel_width, 34)
        header_surf = pygame.Surface(header_rect.size, pygame.SRCALPHA)
        pygame.draw.rect(header_surf, (*COLOR_PATH, 100), header_surf.get_rect(), border_radius=10)
        pygame.draw.rect(header_surf, (*COLOR_PATH, 100), (0, 17, panel_width, 17))
        screen.blit(header_surf, header_rect.topleft)

        title = font.render("PATH COST", True, (255, 255, 255))
        screen.blit(title, (panel_x + 10, panel_y + 10))

        text_y = panel_y + 44
        if result is not None and result.reachable and last_path_breakdown:
            terrain_counts = summarize_path_terrain(grid, result.path)
            
            label = font.render(f"Total: {result.total_cost:.1f}", True, COLOR_TEXT)
            screen.blit(label, (panel_x + 10, text_y))
            text_y += 24
            
            label = font.render(f"Path length: {len(result.path)} cells", True, COLOR_TEXT)
            screen.blit(label, (panel_x + 10, text_y))
            text_y += 32

            for t in (Terrain.GRASS, Terrain.MUD, Terrain.WATER):
                count = terrain_counts.get(t, 0)
                draw_terrain_swatch(screen, panel_x + 10, text_y, t)
                
                total = len(result.path)
                bar_width = int((count / total) * (panel_width - 100)) if total > 0 else 0
                if bar_width > 0:
                    bar_rect = pygame.Rect(panel_x + 28, text_y + 8, bar_width, 6)
                    pygame.draw.rect(screen, TERRAIN_COLOR[t], bar_rect, border_radius=3)
                
                cost_text = f"{count}x{TERRAIN_COST[t]}={count*TERRAIN_COST[t]}"
                label = font.render(cost_text, True, COLOR_TEXT)
                screen.blit(label, (panel_x + 32 + max(bar_width, 10), text_y + 2))
                text_y += 24
        else:
            label = font.render("Total: --", True, COLOR_TEXT)
            screen.blit(label, (panel_x + 10, text_y))
            text_y += 24
            label = font.render("Path length: --", True, COLOR_TEXT)
            screen.blit(label, (panel_x + 10, text_y))
            text_y += 32
            
            for t in (Terrain.GRASS, Terrain.MUD, Terrain.WATER):
                draw_terrain_swatch(screen, panel_x + 10, text_y, t)
                label = font.render(f"-- x {TERRAIN_COST[t]}", True, COLOR_TEXT)
                screen.blit(label, (panel_x + 28, text_y + 2))
                text_y += 24

        if shake_timer > 0.0:
            intensity = int(shake_timer * 10)
            if intensity > 0:
                dx, dy = random.randint(-intensity, intensity), random.randint(-intensity, intensity)
                temp = screen.copy()
                screen.fill((0, 0, 0))
                screen.blit(temp, (dx, dy))

        pygame.display.flip()

    running = True
    while running:
        dt = clock.tick(FPS) / 1500.0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == getattr(pygame, f"K_{KEYBINDS['toggle_diagonal']}"):
                    allow_diagonal = not allow_diagonal
                elif event.key == getattr(pygame, f"K_{KEYBINDS['toggle_heatmap']}"):
                    show_heatmap = not show_heatmap
                elif event.key == getattr(pygame, f"K_{KEYBINDS['toggle_cost_labels']}"):
                    show_cost_labels = not show_cost_labels
                elif event.key == getattr(pygame, f"K_{KEYBINDS['restart']}"):
                    reset_world()
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                handle_left_click(event.pos)
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 3:
                handle_right_click(event.pos)

        update(dt)
        draw()

    pygame.quit()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())